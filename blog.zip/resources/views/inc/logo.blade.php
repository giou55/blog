<div style="background: #465022" class="container-fluid">
<div class="container">
    <img style="height:100px;margin:10px 0" src="/storage/logo.png" alt="logo">
    <img style="height:40px;margin:30px 0" class="pull-right" src="/storage/icons.png" alt="icons">
</div>
</div>