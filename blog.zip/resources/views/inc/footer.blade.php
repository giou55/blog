<div style="background: #120; color: #fff; text-align: center; padding: 20px;margin-top: 20px;" class="container-fluid">
    <div class="container">
        <p>Wildlife - <span id="year"></span></p>
    </div>
    <script>
        var d = new Date();
        document.getElementById("year").innerHTML = d.getFullYear();
    </script>
</div>