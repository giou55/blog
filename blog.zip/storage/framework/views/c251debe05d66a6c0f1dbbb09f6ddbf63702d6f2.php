<?php $__env->startSection('content'); ?>
<div class="jumbotron">

    <a href="/category/<?php echo e($post->category); ?>" class="btn btn-default">Πίσω</a>

    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $post->user_id): ?>

            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Διαγραφή', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>


            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-default pull-right" style="margin-right: 20px;">Επεξεργασία</a>
        <?php endif; ?>
    <?php endif; ?>

    <h2><?php echo e($post->title); ?></h2>
    <img style="width:70%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" alt="">
    <br><br>
    <div>
        <?php echo $post->body; ?>

    </div>
    <hr>
    <small>Δημοσιεύτηκε στις <b><?php echo e(date('d-m-Y', strtotime($post->created_at))); ?></b> από <b><?php echo e($post->user->name); ?></b></small>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>