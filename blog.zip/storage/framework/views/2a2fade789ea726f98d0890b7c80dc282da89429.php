<?php
if(count($posts) > 0) {
    switch ($category) {
        case "proorismoi":
            $category = "Προορισμοί";
            break;
        case "drastiriotites":
            $category = "Δραστηριότητες";
            break;
        case "geuseis":
            $category = "Γεύσεις";
            break;
        case "eidhseis":
            $category = "Ειδήσεις";
            break;
        case "exoplismos":
            $category = "Εξοπλισμός";
            break;
        case "vouno":
            $category = "Βουνό";
            break;
        case "thalassa":
            $category = "Θάλασσα";
            break;
        default:
            $category = "Άρθρα";
    }
} else {
    $category = "Άρθρα";
}
?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($category); ?></h1>
    <?php echo e($posts->links()); ?>


    <?php if(count($posts) > 0): ?>
        <div class="container jumbotron">
            <div>
                <div class="row" style="display: flex;flex-wrap: wrap;">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-xs-12" style="margin:20px 0">
                            <img style="width:80%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" alt="">
                            <h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
                            <small>Δημοσιεύτηκε στις <b><?php echo e(date('d-m-Y', strtotime($post->created_at))); ?></b> από <b><?php echo e($post->user->name); ?></b></small>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <p>Δεν βρέθηκαν άρθρα</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>