<?php $__env->startSection('content'); ?>
    <h1>Επεξεργασία άρθρου</h1>
    <?php echo Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('title', 'Τίτλος')); ?>

            <?php echo e(Form::text('title', $post->title, ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('category', 'Κατηγορία')); ?>

            <?php echo e(Form::select('category', ['proorismoi' => 'Προορισμοί', 'drastiriotites' => 'Δραστηριότητες', 'geuseis' => 'Γεύσεις', 'eidhseis' => 'Ειδήσεις', 'exoplismos' => 'Εξοπλισμός', 'vouno' => 'Βουνό', 'thalassa' => 'Θάλασσα'], 'topia', ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('body', 'Κείμενο')); ?>

            <?php echo e(Form::textarea('body', $post->body, ['id' => 'article-ckeditor', 'class' => 'form-control', 
                                                   'placeholder' => 'Body Text'])); ?>

        </div>
        <div class="form-group">
                <?php echo e(Form::file('cover_image')); ?>

        </div>
        <?php echo e(Form::hidden('_method', 'PUT')); ?>

        <?php echo e(Form::submit('Υποβολή', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>